extends Node3D
# Enemy projectile. Moves along a ray each physics frame, damages the target it hits, and is removed on any hit.

var dir := Vector3.FORWARD
var speed := 30.0
var damage := 8.0
var target = null
var life := 4.0

func setup(origin: Vector3, direction: Vector3, tgt, dmg: float) -> void:
    position = origin
    dir = direction
    target = tgt
    damage = dmg

func _ready() -> void:
    var mi := MeshInstance3D.new()
    var s := SphereMesh.new()
    s.radius = 0.07
    s.height = 0.14
    mi.mesh = s
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color(1, 0.5, 0.2)
    mat.emission_enabled = true
    mat.emission = Color(1, 0.4, 0.1)
    mat.emission_energy_multiplier = 4.0
    mi.material_override = mat
    add_child(mi)

func _physics_process(delta: float) -> void:
    var from := global_position
    var to := from + dir * speed * delta
    life -= delta
    var q := PhysicsRayQueryParameters3D.create(from, to)
    var hit := get_world_3d().direct_space_state.intersect_ray(q)
    if not hit.is_empty():
        if target != null and hit.collider == target:
            target.take_damage(damage)
        queue_free()
        return
    global_position = to
    if life <= 0.0:
        queue_free()
