extends CharacterBody3D
# Basic enemy AI with two types.
#   GRUNT:   idles/wanders, rushes the player when in range, melee attacks.
#   SHOOTER: keeps distance, strafes, fires projectiles with inaccuracy.

signal died(kind)

const Humanoid := preload("res://scripts/humanoid.gd")
const ProjectileScript := preload("res://scripts/projectile.gd")

const GRUNT := 0
const SHOOTER := 1
const GRAVITY := 20.0
const AGGRO_RANGE := 30.0

var kind := GRUNT
var target = null
var health := 60.0
var speed := 3.2
var attack_timer := 0.0
var alive := true
var wander_timer := 0.0
var wander_dir := Vector3.ZERO
var walk_t := 0.0
var strafe_sign := 1.0
var legs: Array = []
var arms: Array = []
var visual: Node3D
var body_shape: CollisionShape3D

func _ready() -> void:
    var cs := CollisionShape3D.new()
    var cap := CapsuleShape3D.new()
    cap.radius = 0.35
    cap.height = 1.8
    cs.shape = cap
    cs.position.y = 0.9
    add_child(cs)
    body_shape = cs
    strafe_sign = 1.0 if randf() < 0.5 else -1.0

    var shirt := Color(0.55, 0.15, 0.12) if kind == GRUNT else Color(0.12, 0.2, 0.4)
    var parts := Humanoid.build(self, shirt, Color(0.2, 0.2, 0.22), Color(0.7, 0.55, 0.45), Color(0.15, 0.15, 0.15))
    visual = parts["body"]
    legs = parts["legs"]
    arms = parts["arms"]

    if kind == GRUNT:
        health = 60.0
        speed = 3.2
    else:
        health = 40.0
        speed = 2.4
        var rifle := MeshInstance3D.new()
        var rb := BoxMesh.new()
        rb.size = Vector3(0.08, 0.12, 0.7)
        rifle.mesh = rb
        var rm := StandardMaterial3D.new()
        rm.albedo_color = Color(0.1, 0.1, 0.1)
        rm.metallic = 0.5
        rifle.material_override = rm
        rifle.position = Vector3(0.25, 1.25, -0.4)
        visual.add_child(rifle)

func _physics_process(delta: float) -> void:
    if not alive:
        return
    var dist := 999.0
    var dir := Vector3.ZERO
    if target != null and target.alive:
        var to: Vector3 = target.global_position - global_position
        to.y = 0.0
        dist = to.length()
        if dist > 0.01:
            dir = to / dist

    var move := Vector3.ZERO
    if dist < AGGRO_RANGE:
        move = _combat(dir, dist, delta)
        _face(dir, delta)
    else:
        move = _wander(delta)
        if move.length() > 0.01:
            _face(move.normalized(), delta)

    velocity.x = move.x
    velocity.z = move.z
    if is_on_floor():
        velocity.y = 0.0
    else:
        velocity.y -= GRAVITY * delta
    move_and_slide()
    _animate(delta, move.length())

func _combat(dir: Vector3, dist: float, delta: float) -> Vector3:
    attack_timer -= delta
    var move := Vector3.ZERO
    if randf() < 0.01:
        strafe_sign = -strafe_sign
    if kind == GRUNT:
        if dist > 1.6:
            move = dir * speed
        elif attack_timer <= 0.0:
            target.take_damage(9.0)
            attack_timer = 1.0
    else:
        if dist > 13.0:
            move = dir * speed
        elif dist < 7.0:
            move = -dir * speed * 0.8
        else:
            move = dir.cross(Vector3.UP) * speed * 0.6 * strafe_sign
        if attack_timer <= 0.0:
            _shoot()
            attack_timer = randf_range(1.4, 2.0)
    return move

func _wander(delta: float) -> Vector3:
    wander_timer -= delta
    if wander_timer <= 0.0:
        wander_timer = randf_range(2.0, 4.0)
        if randf() < 0.6:
            var a := randf() * TAU
            wander_dir = Vector3(cos(a), 0.0, sin(a))
        else:
            wander_dir = Vector3.ZERO
    return wander_dir * speed * 0.35

func _face(dir: Vector3, delta: float) -> void:
    # Model faces -Z; yaw that turns -Z toward dir.
    var target_yaw := atan2(-dir.x, -dir.z)
    rotation.y = lerp_angle(rotation.y, target_yaw, clampf(delta * 8.0, 0.0, 1.0))

func _shoot() -> void:
    var origin := visual.to_global(Vector3(0.25, 1.25, -0.8))
    var aim: Vector3 = target.global_position + Vector3(0, 1.1, 0)
    aim += Vector3(randf_range(-0.6, 0.6), randf_range(-0.3, 0.3), randf_range(-0.6, 0.6))
    var p = ProjectileScript.new()
    p.setup(origin, (aim - origin).normalized(), target, 8.0)
    get_parent().add_child(p)

func _animate(delta: float, spd: float) -> void:
    walk_t += delta * spd * 3.0
    var amount := clampf(spd / maxf(speed, 0.01), 0.0, 1.0)
    var swing := sin(walk_t) * 0.6 * amount
    if legs.size() == 2:
        legs[0].rotation.x = swing
        legs[1].rotation.x = -swing
    if arms.size() == 2:
        arms[0].rotation.x = -swing * 0.5
        if kind == SHOOTER:
            arms[1].rotation.x = 1.4
        else:
            arms[1].rotation.x = swing * 0.5
    visual.position.y = absf(sin(walk_t)) * 0.04 * amount

func take_damage(amount: float) -> void:
    if not alive:
        return
    health -= amount
    if health <= 0.0:
        _die()

func _die() -> void:
    alive = false
    body_shape.set_deferred("disabled", true)
    died.emit(kind)
    var t := create_tween()
    t.tween_property(self, "rotation:x", -PI * 0.5, 0.35)
    t.tween_interval(2.0)
    t.tween_callback(queue_free)
