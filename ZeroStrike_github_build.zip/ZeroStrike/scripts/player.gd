extends CharacterBody3D
# Player: joystick/keyboard movement, FPS/TPS camera, shooting, reload, health, ammo.

signal health_changed(value: float)
signal ammo_changed(mag: int, reserve: int)
signal mode_changed(is_fps: bool)
signal died

const Humanoid := preload("res://scripts/humanoid.gd")

const MOVE_SPEED := 5.5
const GRAVITY := 20.0
const MAX_HEALTH := 100.0
const MAG_SIZE := 12
const RESERVE_START := 60
const RELOAD_TIME := 1.4
const FIRE_INTERVAL := 0.11
const DAMAGE := 20.0
const LOOK_SENS := 0.0045
const TPS_OFFSET := Vector3(0.75, 0.25, 3.4)
const PITCH_LIMIT := 1.35
const FPS_GUN_POS := Vector3(0.24, -0.22, -0.5)
const TPS_GUN_POS := Vector3(0.3, -0.25, -0.55)

var game = null
var joystick = null
var health := MAX_HEALTH
var mag := MAG_SIZE
var reserve := RESERVE_START
var is_fps := true
var reloading := false
var reload_timer := 0.0
var fire_cooldown := 0.0
var trigger_held := false
var alive := true
var pitch := 0.0
var walk_t := 0.0
var flash_t := 0.0

var head: Node3D
var camera: Camera3D
var body: Node3D
var legs: Array = []
var arms: Array = []
var gun: Node3D
var muzzle_light: OmniLight3D

func _ready() -> void:
    var cs := CollisionShape3D.new()
    var cap := CapsuleShape3D.new()
    cap.radius = 0.35
    cap.height = 1.8
    cs.shape = cap
    cs.position.y = 0.9
    add_child(cs)

    var parts := Humanoid.build(self, Color(0.2, 0.26, 0.18), Color(0.16, 0.17, 0.15), Color(0.8, 0.62, 0.5), Color(0.1, 0.1, 0.1))
    body = parts["body"]
    legs = parts["legs"]
    arms = parts["arms"]

    head = Node3D.new()
    head.position = Vector3(0, 1.6, 0)
    add_child(head)
    camera = Camera3D.new()
    camera.near = 0.05
    camera.fov = 72.0
    head.add_child(camera)
    camera.current = true

    gun = _build_gun()
    camera.add_child(gun)
    gun.position = FPS_GUN_POS

    muzzle_light = OmniLight3D.new()
    muzzle_light.light_color = Color(1.0, 0.7, 0.3)
    muzzle_light.light_energy = 0.0
    muzzle_light.omni_range = 4.0
    muzzle_light.position = Vector3(0, 0, -0.48)
    gun.add_child(muzzle_light)
    _apply_mode()

func _build_gun() -> Node3D:
    var g := Node3D.new()
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color(0.1, 0.1, 0.11)
    mat.metallic = 0.6
    mat.roughness = 0.4
    var recv := MeshInstance3D.new()
    var bm := BoxMesh.new()
    bm.size = Vector3(0.09, 0.12, 0.42)
    recv.mesh = bm
    recv.material_override = mat
    g.add_child(recv)
    var barrel := MeshInstance3D.new()
    var cm := CylinderMesh.new()
    cm.top_radius = 0.02
    cm.bottom_radius = 0.02
    cm.height = 0.28
    barrel.mesh = cm
    barrel.material_override = mat
    barrel.rotation_degrees.x = 90
    barrel.position = Vector3(0, 0.02, -0.33)
    g.add_child(barrel)
    return g

func toggle_mode() -> void:
    is_fps = not is_fps
    _apply_mode()
    mode_changed.emit(is_fps)

func _apply_mode() -> void:
    body.visible = not is_fps
    if is_fps:
        gun.reparent(camera, false)
        gun.position = FPS_GUN_POS
    else:
        gun.reparent(head, false)
        gun.position = TPS_GUN_POS

func look(rel: Vector2) -> void:
    if not alive:
        return
    rotate_y(-rel.x * LOOK_SENS)
    pitch = clampf(pitch - rel.y * LOOK_SENS, -PITCH_LIMIT, PITCH_LIMIT)
    head.rotation.x = pitch

func _physics_process(delta: float) -> void:
    if not alive:
        return
    var stick := Vector2.ZERO
    if joystick != null:
        stick = joystick.move_vector
    var kb := Vector2(
        float(Input.is_physical_key_pressed(KEY_D)) - float(Input.is_physical_key_pressed(KEY_A)),
        float(Input.is_physical_key_pressed(KEY_S)) - float(Input.is_physical_key_pressed(KEY_W)))
    if kb.length() > stick.length():
        stick = kb
    var move := stick.limit_length(1.0)

    var wish := transform.basis * Vector3(move.x, 0.0, move.y) * MOVE_SPEED
    velocity.x = wish.x
    velocity.z = wish.z
    if is_on_floor():
        velocity.y = 0.0
    else:
        velocity.y -= GRAVITY * delta
    move_and_slide()

    # Procedural walk cycle
    walk_t += delta * move.length() * 9.0
    var swing := sin(walk_t) * 0.7 * move.length()
    if legs.size() == 2:
        legs[0].rotation.x = swing
        legs[1].rotation.x = -swing
    if arms.size() == 2:
        arms[0].rotation.x = -swing * 0.6
        arms[1].rotation.x = swing * 0.6

    fire_cooldown = maxf(0.0, fire_cooldown - delta)
    if reloading:
        reload_timer -= delta
        if reload_timer <= 0.0:
            _finish_reload()
    elif trigger_held and fire_cooldown <= 0.0:
        _try_fire()

    var target_pos := TPS_OFFSET if not is_fps else Vector3.ZERO
    camera.position = camera.position.lerp(target_pos, minf(1.0, delta * 10.0))

    if flash_t > 0.0:
        flash_t -= delta
        if flash_t <= 0.0:
            muzzle_light.light_energy = 0.0

func _try_fire() -> void:
    if mag <= 0:
        start_reload()
        return
    mag -= 1
    fire_cooldown = FIRE_INTERVAL
    ammo_changed.emit(mag, reserve)
    muzzle_light.light_energy = 4.0
    flash_t = 0.05

    var cam_xf := camera.global_transform
    var from := cam_xf.origin
    var to := from - cam_xf.basis.z * 200.0
    var q := PhysicsRayQueryParameters3D.create(from, to)
    q.exclude = [get_rid()]
    var hit := get_world_3d().direct_space_state.intersect_ray(q)
    if not hit.is_empty():
        var c = hit.collider
        if c.has_method("take_damage"):
            c.take_damage(DAMAGE)
        if game != null:
            game.spawn_impact(hit.position)
    if mag == 0:
        start_reload()

func start_reload() -> void:
    if reloading or not alive or mag == MAG_SIZE or reserve <= 0:
        return
    reloading = true
    reload_timer = RELOAD_TIME
    if game != null:
        game.show_msg("RELOADING")

func _finish_reload() -> void:
    var take := mini(MAG_SIZE - mag, reserve)
    mag += take
    reserve -= take
    reloading = false
    ammo_changed.emit(mag, reserve)

func take_damage(amount: float) -> void:
    if not alive:
        return
    health = maxf(0.0, health - amount)
    health_changed.emit(health)
    if health <= 0.0:
        alive = false
        trigger_held = false
        died.emit()

func reset_player(pos: Vector3) -> void:
    position = pos
    rotation = Vector3.ZERO
    velocity = Vector3.ZERO
    pitch = 0.0
    head.rotation.x = 0.0
    health = MAX_HEALTH
    mag = MAG_SIZE
    reserve = RESERVE_START
    reloading = false
    fire_cooldown = 0.0
    trigger_held = false
    alive = true
    health_changed.emit(health)
    ammo_changed.emit(mag, reserve)
