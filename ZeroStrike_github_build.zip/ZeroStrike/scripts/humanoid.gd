extends RefCounted
# Builds a simple blocky soldier from primitives: body, two legs (hip pivots), two arms (shoulder pivots).

static func _box(parent: Node3D, size: Vector3, pos: Vector3, color: Color) -> MeshInstance3D:
    var mi := MeshInstance3D.new()
    var bm := BoxMesh.new()
    bm.size = size
    mi.mesh = bm
    var mat := StandardMaterial3D.new()
    mat.albedo_color = color
    mat.roughness = 0.75
    mi.material_override = mat
    mi.position = pos
    mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON
    parent.add_child(mi)
    return mi

static func build(root: Node3D, shirt: Color, pants: Color, skin: Color, gear: Color) -> Dictionary:
    var body := Node3D.new()
    root.add_child(body)
    _box(body, Vector3(0.5, 0.7, 0.3), Vector3(0, 1.2, 0), shirt)
    _box(body, Vector3(0.3, 0.32, 0.3), Vector3(0, 1.66, 0), skin)
    _box(body, Vector3(0.54, 0.4, 0.34), Vector3(0, 1.25, 0), gear)
    var legs: Array = []
    for sx in [-1.0, 1.0]:
        var hip := Node3D.new()
        hip.position = Vector3(0.14 * sx, 0.85, 0)
        body.add_child(hip)
        _box(hip, Vector3(0.2, 0.85, 0.22), Vector3(0, -0.425, 0), pants)
        legs.append(hip)
    var arms: Array = []
    for sx in [-1.0, 1.0]:
        var sh := Node3D.new()
        sh.position = Vector3(0.35 * sx, 1.5, 0)
        body.add_child(sh)
        _box(sh, Vector3(0.18, 0.7, 0.18), Vector3(0, -0.35, 0), shirt)
        arms.append(sh)
    return {"body": body, "legs": legs, "arms": arms}
