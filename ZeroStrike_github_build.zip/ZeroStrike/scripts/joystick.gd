extends Control
# Virtual on-screen joystick. move_vector: x = right, y = down (negative y = forward).

var move_vector := Vector2.ZERO
var radius := 90.0
var _touch_index := -1
var _knob := Vector2.ZERO

func _ready() -> void:
    mouse_filter = Control.MOUSE_FILTER_STOP

func _gui_input(event: InputEvent) -> void:
    if event is InputEventScreenTouch:
        if event.pressed and _touch_index == -1:
            _touch_index = event.index
            _update(event.position)
            accept_event()
        elif not event.pressed and event.index == _touch_index:
            _release()
            accept_event()
    elif event is InputEventScreenDrag and event.index == _touch_index:
        _update(event.position)
        accept_event()
    elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
        # Desktop testing fallback
        if event.pressed and _touch_index == -1:
            _touch_index = -2
            _update(event.position)
        elif not event.pressed and _touch_index == -2:
            _release()
    elif event is InputEventMouseMotion and _touch_index == -2:
        _update(event.position)

func _update(local_pos: Vector2) -> void:
    var v := (local_pos - size * 0.5).limit_length(radius)
    _knob = v
    move_vector = v / radius
    queue_redraw()

func _release() -> void:
    _touch_index = -1
    move_vector = Vector2.ZERO
    _knob = Vector2.ZERO
    queue_redraw()

func _draw() -> void:
    var c := size * 0.5
    draw_circle(c, radius + 10.0, Color(1, 1, 1, 0.12))
    draw_arc(c, radius + 10.0, 0.0, TAU, 48, Color(1, 1, 1, 0.3), 3.0)
    draw_circle(c + _knob, 42.0, Color(1, 1, 1, 0.35))
