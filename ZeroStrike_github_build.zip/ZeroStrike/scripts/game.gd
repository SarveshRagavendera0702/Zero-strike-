extends Node3D
# Main controller: builds environment, map, HUD, menus, waves and game state.

const PlayerScript := preload("res://scripts/player.gd")
const EnemyScript := preload("res://scripts/enemy.gd")
const JoystickScript := preload("res://scripts/joystick.gd")

enum State { MENU, PLAYING, DEAD }

const MAP_HALF := 38.0
const SPAWN_RADIUS := 24.0

var state: int = State.MENU
var rng := RandomNumberGenerator.new()
var world_root: Node3D
var enemies_root: Node3D
var player
var joystick: Control
var hud: CanvasLayer
var play_hud: Control
var health_bar: ProgressBar
var ammo_label: Label
var wave_label: Label
var msg_label: Label
var mode_button: Button
var fire_button: Button
var flash_rect: ColorRect
var menu_panel: Control
var dead_panel: Control
var dead_label: Label
var fire_held := false
var look_index := -1
var last_health := 100.0
var score := 0
var wave := 0
var enemies_alive := 0
var wave_pause := 2.0
var msg_time := 0.0

func _ready() -> void:
    rng.seed = 1337
    _build_environment()
    world_root = Node3D.new()
    add_child(world_root)
    _build_map()
    enemies_root = Node3D.new()
    add_child(enemies_root)
    _build_hud()

    player = PlayerScript.new()
    player.game = self
    player.joystick = joystick
    world_root.add_child(player)
    player.health_changed.connect(_on_health_changed)
    player.ammo_changed.connect(_on_ammo_changed)
    player.mode_changed.connect(_on_mode_changed)
    player.died.connect(_on_player_died)
    show_menu()

# ---------- world ----------

func _build_environment() -> void:
    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-55, -35, 0)
    sun.light_energy = 1.3
    sun.light_color = Color(1.0, 0.95, 0.85)
    sun.shadow_enabled = true
    add_child(sun)

    var sky_mat := ProceduralSkyMaterial.new()
    sky_mat.sky_top_color = Color(0.25, 0.4, 0.62)
    sky_mat.sky_horizon_color = Color(0.7, 0.72, 0.74)
    sky_mat.ground_bottom_color = Color(0.2, 0.2, 0.2)
    var sky := Sky.new()
    sky.sky_material = sky_mat
    var env := Environment.new()
    env.background_mode = Environment.BG_SKY
    env.sky = sky
    env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
    env.ambient_light_energy = 0.6
    env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    env.fog_enabled = true
    env.fog_density = 0.008
    env.fog_light_color = Color(0.6, 0.65, 0.7)
    var we := WorldEnvironment.new()
    we.environment = env
    add_child(we)

func _mat(color: Color, rough: float) -> StandardMaterial3D:
    var m := StandardMaterial3D.new()
    m.albedo_color = color
    m.roughness = rough
    return m

func _static_box(pos: Vector3, size: Vector3, color: Color) -> void:
    var body := StaticBody3D.new()
    body.position = pos
    var mi := MeshInstance3D.new()
    var bm := BoxMesh.new()
    bm.size = size
    mi.mesh = bm
    mi.material_override = _mat(color, 0.9)
    mi.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_ON
    body.add_child(mi)
    var cs := CollisionShape3D.new()
    var bs := BoxShape3D.new()
    bs.size = size
    cs.shape = bs
    body.add_child(cs)
    world_root.add_child(body)

func _build_map() -> void:
    _static_box(Vector3(0, -0.5, 0), Vector3(MAP_HALF * 2.0 + 8.0, 1.0, MAP_HALF * 2.0 + 8.0), Color(0.28, 0.3, 0.27))
    var h := 4.0
    var concrete := Color(0.5, 0.48, 0.44)
    _static_box(Vector3(0, h * 0.5, -MAP_HALF), Vector3(MAP_HALF * 2.0, h, 1.0), concrete)
    _static_box(Vector3(0, h * 0.5, MAP_HALF), Vector3(MAP_HALF * 2.0, h, 1.0), concrete)
    _static_box(Vector3(-MAP_HALF, h * 0.5, 0), Vector3(1.0, h, MAP_HALF * 2.0), concrete)
    _static_box(Vector3(MAP_HALF, h * 0.5, 0), Vector3(1.0, h, MAP_HALF * 2.0), concrete)

    var colors := [Color(0.45, 0.3, 0.16), Color(0.36, 0.37, 0.38), Color(0.5, 0.48, 0.44)]
    for i in 40:
        var size := Vector3(rng.randf_range(1.5, 4.0), rng.randf_range(0.8, 2.5), rng.randf_range(1.5, 4.0))
        var pos := Vector3(rng.randf_range(-MAP_HALF + 4, MAP_HALF - 4), size.y * 0.5, rng.randf_range(-MAP_HALF + 4, MAP_HALF - 4))
        if Vector2(pos.x, pos.z).length() < 9.0:
            continue
        _static_box(pos, size, colors[i % 3])
    for i in 6:
        var pos := Vector3(rng.randf_range(-MAP_HALF + 6, MAP_HALF - 6), 2.0, rng.randf_range(-MAP_HALF + 6, MAP_HALF - 6))
        if Vector2(pos.x, pos.z).length() < 9.0:
            continue
        _static_box(pos, Vector3(1.2, 4.0, 1.2), Color(0.6, 0.6, 0.58))

func spawn_impact(pos: Vector3) -> void:
    var mi := MeshInstance3D.new()
    var s := SphereMesh.new()
    s.radius = 0.08
    s.height = 0.16
    mi.mesh = s
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color(1, 0.8, 0.4)
    mat.emission_enabled = true
    mat.emission = Color(1, 0.6, 0.2)
    mat.emission_energy_multiplier = 3.0
    mi.material_override = mat
    world_root.add_child(mi)
    mi.global_position = pos
    var t := create_tween()
    t.tween_property(mi, "scale", Vector3.ZERO, 0.25)
    t.tween_callback(mi.queue_free)

# ---------- HUD ----------

func _place(c: Control, ax: float, ay: float, l: float, t: float, r: float, b: float) -> void:
    c.anchor_left = ax
    c.anchor_right = ax
    c.anchor_top = ay
    c.anchor_bottom = ay
    c.offset_left = l
    c.offset_top = t
    c.offset_right = r
    c.offset_bottom = b
    c.mouse_filter = Control.MOUSE_FILTER_IGNORE

func _make_button(text: String, font_size: int, sz: Vector2) -> Button:
    var b := Button.new()
    b.text = text
    b.custom_minimum_size = sz
    b.add_theme_font_size_override("font_size", font_size)
    var n := StyleBoxFlat.new()
    n.bg_color = Color(0.1, 0.1, 0.12, 0.6)
    n.set_corner_radius_all(int(minf(sz.x, sz.y) * 0.5))
    n.set_border_width_all(3)
    n.border_color = Color(1, 1, 1, 0.5)
    var p: StyleBoxFlat = n.duplicate()
    p.bg_color = Color(0.7, 0.12, 0.1, 0.85)
    b.add_theme_stylebox_override("normal", n)
    b.add_theme_stylebox_override("hover", n)
    b.add_theme_stylebox_override("pressed", p)
    b.mouse_filter = Control.MOUSE_FILTER_STOP
    return b

func _make_label(text: String, font_size: int) -> Label:
    var l := Label.new()
    l.text = text
    l.add_theme_font_size_override("font_size", font_size)
    l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
    return l

func _build_hud() -> void:
    hud = CanvasLayer.new()
    add_child(hud)

    play_hud = Control.new()
    play_hud.set_anchors_preset(Control.PRESET_FULL_RECT)
    play_hud.mouse_filter = Control.MOUSE_FILTER_IGNORE
    hud.add_child(play_hud)

    flash_rect = ColorRect.new()
    flash_rect.set_anchors_preset(Control.PRESET_FULL_RECT)
    flash_rect.color = Color(0.8, 0, 0, 0)
    flash_rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
    play_hud.add_child(flash_rect)

    var cross := _make_label("+", 36)
    _place(cross, 0.5, 0.5, -20, -22, 20, 18)
    play_hud.add_child(cross)

    health_bar = ProgressBar.new()
    health_bar.max_value = 100
    health_bar.value = 100
    health_bar.show_percentage = false
    _place(health_bar, 0, 0, 24, 24, 284, 48)
    play_hud.add_child(health_bar)

    wave_label = _make_label("", 22)
    _place(wave_label, 0.5, 0, -200, 20, 200, 60)
    play_hud.add_child(wave_label)

    msg_label = _make_label("", 30)
    _place(msg_label, 0.5, 0.3, -300, 0, 300, 44)
    play_hud.add_child(msg_label)

    mode_button = _make_button("FPS", 22, Vector2(150, 70))
    _place(mode_button, 1, 0, -170, 20, -20, 90)
    mode_button.pressed.connect(func(): player.toggle_mode())
    play_hud.add_child(mode_button)

    ammo_label = _make_label("", 28)
    ammo_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
    _place(ammo_label, 1, 1, -300, -340, -20, -290)
    play_hud.add_child(ammo_label)

    fire_button = _make_button("FIRE", 30, Vector2(160, 160))
    _place(fire_button, 1, 1, -190, -190, -30, -30)
    fire_button.button_down.connect(func(): fire_held = true)
    fire_button.button_up.connect(func(): fire_held = false)
    play_hud.add_child(fire_button)

    var reload_button := _make_button("RELOAD", 20, Vector2(120, 120))
    _place(reload_button, 1, 1, -330, -150, -210, -30)
    reload_button.pressed.connect(func(): player.start_reload())
    play_hud.add_child(reload_button)

    joystick = JoystickScript.new()
    _place(joystick, 0, 1, 30, -270, 270, -30)
    play_hud.add_child(joystick)

    # Menu
    menu_panel = Control.new()
    menu_panel.set_anchors_preset(Control.PRESET_FULL_RECT)
    hud.add_child(menu_panel)
    var dim := ColorRect.new()
    dim.set_anchors_preset(Control.PRESET_FULL_RECT)
    dim.color = Color(0, 0, 0, 0.7)
    menu_panel.add_child(dim)
    var vb := VBoxContainer.new()
    vb.alignment = BoxContainer.ALIGNMENT_CENTER
    vb.add_theme_constant_override("separation", 18)
    _place(vb, 0.5, 0.5, -260, -220, 260, 220)
    menu_panel.add_child(vb)
    vb.add_child(_make_label("ZERO STRIKE", 56))
    vb.add_child(_make_label("Prototype build 0.1", 18))
    vb.add_child(_make_label("Left stick: move    Right side drag: look\nFIRE / RELOAD / FPS-TPS buttons\nDesktop: WASD, RMB look, Space/LMB fire, R reload, F view", 16))
    var start_btn := _make_button("START", 30, Vector2(320, 80))
    start_btn.pressed.connect(start_game)
    vb.add_child(start_btn)

    # Dead screen
    dead_panel = Control.new()
    dead_panel.set_anchors_preset(Control.PRESET_FULL_RECT)
    hud.add_child(dead_panel)
    var dim2 := ColorRect.new()
    dim2.set_anchors_preset(Control.PRESET_FULL_RECT)
    dim2.color = Color(0.3, 0, 0, 0.75)
    dead_panel.add_child(dim2)
    var vb2 := VBoxContainer.new()
    vb2.alignment = BoxContainer.ALIGNMENT_CENTER
    vb2.add_theme_constant_override("separation", 18)
    _place(vb2, 0.5, 0.5, -260, -160, 260, 160)
    dead_panel.add_child(vb2)
    vb2.add_child(_make_label("YOU DIED", 56))
    dead_label = _make_label("", 22)
    vb2.add_child(dead_label)
    var restart_btn := _make_button("RESTART", 30, Vector2(320, 80))
    restart_btn.pressed.connect(start_game)
    vb2.add_child(restart_btn)
    var menu_btn := _make_button("MAIN MENU", 22, Vector2(320, 60))
    menu_btn.pressed.connect(show_menu)
    vb2.add_child(menu_btn)

# ---------- state ----------

func show_menu() -> void:
    state = State.MENU
    _clear_enemies()
    player.set_physics_process(false)
    menu_panel.visible = true
    dead_panel.visible = false
    play_hud.visible = false

func start_game() -> void:
    _clear_enemies()
    score = 0
    wave = 0
    enemies_alive = 0
    wave_pause = 2.0
    fire_held = false
    look_index = -1
    player.reset_player(Vector3.ZERO)
    player.set_physics_process(true)
    state = State.PLAYING
    menu_panel.visible = false
    dead_panel.visible = false
    play_hud.visible = true
    mode_button.text = "FPS" if player.is_fps else "TPS"
    last_health = player.health
    _update_wave_label()
    show_msg("GET READY")

func _clear_enemies() -> void:
    for c in enemies_root.get_children():
        c.queue_free()

func _next_wave() -> void:
    wave += 1
    var count := 2 + wave * 2
    for i in count:
        var e = EnemyScript.new()
        e.kind = EnemyScript.SHOOTER if i % 3 == 2 else EnemyScript.GRUNT
        e.target = player
        e.died.connect(_on_enemy_died)
        enemies_root.add_child(e)
        var ang := rng.randf() * TAU
        var r := SPAWN_RADIUS + rng.randf_range(-3.0, 3.0)
        e.position = Vector3(cos(ang) * r, 0.0, sin(ang) * r)
        enemies_alive += 1
    show_msg("WAVE %d" % wave)
    _update_wave_label()

func _update_wave_label() -> void:
    wave_label.text = "WAVE %d    SCORE %d    ENEMIES %d" % [wave, score, enemies_alive]

func show_msg(text: String) -> void:
    msg_label.text = text
    msg_time = 1.2

# ---------- loop & input ----------

func _process(delta: float) -> void:
    if msg_time > 0.0:
        msg_time -= delta
        if msg_time <= 0.0:
            msg_label.text = ""
    if state != State.PLAYING:
        return
    var pc_fire := OS.has_feature("pc") and (Input.is_key_pressed(KEY_SPACE) or Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT))
    player.trigger_held = fire_held or pc_fire
    if enemies_alive == 0:
        wave_pause -= delta
        if wave_pause <= 0.0:
            _next_wave()
            wave_pause = 4.0

func _unhandled_input(event: InputEvent) -> void:
    if state != State.PLAYING:
        return
    if event is InputEventScreenTouch:
        if event.pressed and look_index == -1 and event.position.x > get_viewport().get_visible_rect().size.x * 0.4:
            look_index = event.index
        elif not event.pressed and event.index == look_index:
            look_index = -1
    elif event is InputEventScreenDrag:
        if event.index == look_index:
            player.look(event.relative)
    elif event is InputEventMouseMotion:
        if event.button_mask & MOUSE_BUTTON_MASK_RIGHT:
            player.look(event.relative)
    elif event is InputEventKey and event.pressed and not event.echo:
        if event.keycode == KEY_F:
            player.toggle_mode()
        elif event.keycode == KEY_R:
            player.start_reload()

# ---------- signal handlers ----------

func _on_health_changed(v: float) -> void:
    health_bar.value = v
    if v < last_health:
        flash_rect.color = Color(0.8, 0, 0, 0.4)
        var t := create_tween()
        t.tween_property(flash_rect, "color:a", 0.0, 0.35)
    last_health = v

func _on_ammo_changed(mag: int, reserve: int) -> void:
    ammo_label.text = "%d / %d" % [mag, reserve]

func _on_mode_changed(is_fps: bool) -> void:
    mode_button.text = "FPS" if is_fps else "TPS"

func _on_enemy_died(kind: int) -> void:
    enemies_alive = maxi(0, enemies_alive - 1)
    score += 150 if kind == EnemyScript.SHOOTER else 100
    _update_wave_label()
    if enemies_alive == 0:
        wave_pause = 4.0
        show_msg("WAVE CLEARED")

func _on_player_died() -> void:
    state = State.DEAD
    fire_held = false
    play_hud.visible = false
    dead_panel.visible = true
    dead_label.text = "Score %d    Wave %d" % [score, wave]
    for e in enemies_root.get_children():
        e.set_physics_process(false)
