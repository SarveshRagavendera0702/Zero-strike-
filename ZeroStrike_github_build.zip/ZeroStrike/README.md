# Zero Strike: 3D Shooter Prototype (Godot 4.3, Android)

## What is included
- FPS/TPS toggle (button or F key on desktop)
- Virtual joystick (left), camera drag (right half), FIRE and RELOAD buttons
- Two enemy types: GRUNT (rushes, melee) and SHOOTER (keeps range, fires projectiles)
- Health (100), ammo (12 magazine / 60 reserve), reload (1.4 s)
- Wave spawning, score, death screen, restart, main menu
- Shadows, fog, procedural sky, procedural walk animation

## Step 1: Install tools (all free)
1. Godot 4.3 standard edition: https://godotengine.org/download (Windows/Linux/macOS)
2. Godot export templates: in Godot, Editor > Manage Export Templates > Download for 4.3.
3. JDK 17 and Android SDK. Easiest: install Android Studio, then in SDK Manager install
   "Android SDK Platform 34", "Build-Tools 34.0.0", and "Command-line Tools".
4. In Godot: Editor > Editor Settings > Export > Android. Set "Java SDK Path" (JDK 17 folder)
   and "Android SDK Path" (the SDK folder, e.g. ~/Android/Sdk).
5. Optional: Editor > Editor Settings > Export > Android > Debug Keystore (leave empty to use the auto-generated debug key).

## Step 2: Test on desktop first (recommended)
1. Open Godot, Import, select ZeroStrike/project.godot.
2. Press F5. Controls: WASD move, mouse RIGHT-drag look, SPACE or LEFT mouse fire, R reload, F toggle FPS/TPS.
3. Click START. Kill enemies in waves. Confirm: movement, both camera modes, shooting hits enemies,
   enemies chase and attack, health drops when hit, reload works, death screen and restart work.
4. Check the Output panel (bottom) for red errors. Report any error text.

## Step 3: Build the APK
1. Project > Export. The "Android" preset is already in export_presets.cfg. Export path is ../build/ZeroStrike-debug.apk
   (creates ZeroStrike/../build, i.e. /mnt/user-data/outputs/build/).
2. Click "Export Project" (Debug, not release). Save.
   Note: if Godot reports a missing template, install it (Step 1, item 2).

## Step 4: Install on Android phone
1. Phone: Settings > About phone > tap Build number 7 times; then Developer options > enable USB debugging.
2. Connect via USB, accept the debug prompt.
3. Run: adb install -r build/ZeroStrike-debug.apk
   (adb comes with Android SDK platform-tools.)
   Or copy the APK to the phone and install it, allowing "install unknown apps".

## Known bugs and limitations (honest list)
- NOT YET COMPILED OR RUN. This project was written without access to Godot or an Android SDK
  in the build environment. Expect possible minor script errors on first run; check the Output panel.
- Visuals are primitive boxes and capsules, not realistic models. No free rigged character
  or animation assets were included; swap in Kenney/Quaternius/Mixamo models later.
  "Realistic" look requires textures, a real rig, and a proper lighting pass.
- No animation library: walk cycle is procedural (leg/arm swing) only. No death or fire animations.
- Enemies walk straight at the player; no navigation mesh. They can get stuck on corners.
- Enemy and player projectiles do not check line of sight for aggro; enemies can shoot through walls
  only if the ray is clear, so cover works, but enemies can track you through walls.
- TPS camera does not collide with walls (it can clip into geometry).
- In TPS the gun floats in front of the head; it is not held by a hand.
- No enemy health bars, no hit-reaction animation, no sound effects, no music.
- No pickups: ammo and health are not restored during play (restart resets them).
- Performance is untested on real hardware. Shadows and fog are on; if a low-end phone stutters,
  disable shadows (DirectionalLight3D > Shadow > Enabled) in game.gd _build_environment().
- Touch controls layout is fixed for landscape. Tested layout only in desktop window size 1280x720.
- Debug APK only. Release signing is not configured.
- Platform compatibility: Android 7.0+ (min SDK 24), arm64 devices only.

## Next step after first successful run
Open the project, press F5, play one full wave, and report any error text or behavior that differs
from the test list. Then export the APK and install it.
