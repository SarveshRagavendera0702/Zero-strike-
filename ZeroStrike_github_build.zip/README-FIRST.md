# Get the Zero Strike APK (no installs needed)

1. Create a free GitHub account at github.com (if you don't have one).
2. Click "+" > "New repository". Name it ZeroStrike. Choose Public. Click "Create repository".
   (Public means the APK download needs no login on your phone.)
3. Unzip ZeroStrike_github_build.zip on your computer.
4. On the new repository page, click "uploading an existing file".
   Drag ALL the unzipped items (the .github folder and the ZeroStrike folder) into the page.
   Click "Commit changes".
   - If the .github folder does not upload, click "Add file" > "Create new file", type
     .github/workflows/build-apk.yml as the name, and paste the contents of that file from the zip.
5. Click the "Actions" tab. Wait about 5-10 minutes until "Build Android APK" shows a green check.
6. Open the "Releases" section on the right side of the repository page. Open the newest release.
7. On your Android phone, open that release page in your browser and tap ZeroStrike-debug.apk.
8. If asked, allow installing from this browser (Settings > Apps > Special access > Install unknown apps).
9. Tap Install, then open Zero Strike.

If the Actions run shows a red X, open it, copy the red error lines, and send them to me.
